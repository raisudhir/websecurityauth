package com.cisco.websecurityauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsecurityauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsecurityauthApplication.class, args);
	}

}
