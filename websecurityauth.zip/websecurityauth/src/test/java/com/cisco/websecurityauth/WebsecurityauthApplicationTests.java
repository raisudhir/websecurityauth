package com.cisco.websecurityauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsecurityauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
