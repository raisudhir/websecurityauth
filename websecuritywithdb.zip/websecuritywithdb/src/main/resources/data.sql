
INSERT into users(username,password,email,enabled) values ('sudhir','{noop}sudhirpass','sudhir@gmail.com',true);
INSERT into users(username,password,email,enabled) values ('user','{noop}userpass','user@gmail.com',true);
INSERT into users(username,password,email,enabled) values ('admin','{noop}adminpass','admin@gmail.com',true);
INSERT into authorities values ('user','USER');
INSERT into authorities values ('admin','ADMIN');
INSERT into authorities values ('sudhir','ADMIN');

