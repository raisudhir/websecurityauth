package com.cisco.websecuritywithdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsecuritywithdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsecuritywithdbApplication.class, args);
	}

}
