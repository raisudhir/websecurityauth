package com.cisco.websecuritywithdb;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@GetMapping("/hello")
	public String sayHello(String name) {
		return "Hello "+name;
	}
	
	//http://localhost:8080/admin/hello?name=Melwin
	@GetMapping("/admin/hello")
	public String sayAdminHello(String name) {
		return "Hello Admin "+name;
	}


}
