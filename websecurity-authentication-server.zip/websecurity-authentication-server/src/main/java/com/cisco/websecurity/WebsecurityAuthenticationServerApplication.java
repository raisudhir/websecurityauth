package com.cisco.websecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsecurityAuthenticationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsecurityAuthenticationServerApplication.class, args);
	}

}
