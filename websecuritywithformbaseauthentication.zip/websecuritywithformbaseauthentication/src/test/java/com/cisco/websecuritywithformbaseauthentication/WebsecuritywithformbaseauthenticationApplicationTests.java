package com.cisco.websecuritywithformbaseauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsecuritywithformbaseauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
