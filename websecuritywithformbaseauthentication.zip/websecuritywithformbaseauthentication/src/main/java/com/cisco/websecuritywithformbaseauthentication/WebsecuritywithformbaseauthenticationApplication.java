package com.cisco.websecuritywithformbaseauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsecuritywithformbaseauthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsecuritywithformbaseauthenticationApplication.class, args);
	}

}
