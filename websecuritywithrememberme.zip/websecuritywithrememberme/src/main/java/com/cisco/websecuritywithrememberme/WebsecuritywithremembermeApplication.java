package com.cisco.websecuritywithrememberme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsecuritywithremembermeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsecuritywithremembermeApplication.class, args);
	}

}
